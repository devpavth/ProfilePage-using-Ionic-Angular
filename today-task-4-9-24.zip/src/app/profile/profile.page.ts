import { Component, OnInit } from '@angular/core';
import { Camera, CameraResultType } from '@capacitor/camera';
import {CameraSource} from '@capacitor/camera/dist/esm/definitions';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  selectedTab: string = 'ads';
  // imageUri: string | undefined;
  imageSource: any;

  constructor(private domSanitizer: DomSanitizer) { 
    this.imageSource = 'assets/bg/background.jpg';
  }

  ngOnInit() {
  }


  takePicture = async () => {
    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Prompt,
      saveToGallery: true
    });
    // this.imageSource = image.dataUrl;

    this.imageSource = this.domSanitizer.bypassSecurityTrustUrl(image.webPath ? image.webPath : "");
  }

  getPhoto(){
    return this.imageSource;
  }

}

  // async takePicture() {
  //   try {
  //     const image = await Camera.getPhoto({
  //       quality: 90,
  //       allowEditing: false,
  //       resultType: CameraResultType.DataUrl
  //       source: CameraSource
  //     });

  //     this.imageUri = image.webPath; // Store the image URI to display
  //     console.log('Image URI:', this.imageUri);
  //   } catch (error) {
  //     console.error('Error taking picture:', error);
  //   }
  // }

